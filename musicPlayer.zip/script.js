let progressBar = document.getElementById("ProgessBar");
let song = document.getElementById("songPath")
let controlIcons = document.getElementById("ctrlIcon");
song.onloadedmetadata = function () {
    progressBar.Max = song.duration;
    progressBar.value = song.currentTime;
}
function playSong() {
    if (controlIcons.classList.contains("fa-pause")){
        song.pause();
        controlIcons.classList.remove("fa-pause");
        controlIcons.classList.add("fa-play");

    }
    else{
        song.play();
        controlIcons.classList.remove("fa-play");
        controlIcons.classList.add("fa-pause");

    }
};
if (song.play()) {
    setInterval(() => {
        progressBar.value = song.currentTime;
        document.getElementById("playedDuration").innerHTML = Math.round(song.currentTime);
    }, 1000)
};
document.getElementById("totalDuration").innerHTML = Math.round(song.duration);
progressBar.onchange = function() {
    song.play();
    song.currentTime = progressBar.value ;
    controlIcons.classList.remove("fa-play");
    controlIcons.classList.add("fa-pause");
};